
class Config {
  constructor() {
    this.ipCheckURL = 'https://ipinfo.io/json';
    this.wssHost = 'proxy.wynd.network:4444';
    this.retryInterval = 20000;
    this.proxyUsername = '3c1ohfpn1b2di5w';
    this.proxyPassword = 'ts88vggq1qmjsdd';
  }
}
module.exports = Config;
